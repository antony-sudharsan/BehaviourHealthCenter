// import $ from 'jquery';

// $('.main-nav a').on('click', function(e) {
//     if($(this).parent().hasClass('has-submenu')) {
//         e.preventDefault();
//     }
//     if(!$(this).hasClass('submenu')) {
//         $('ul', $(this).parents('ul:first')).slideUp(350);
//         $('a', $(this).parents('ul:first')).removeClass('submenu');
//         $(this).next('ul').slideDown(350);
//         $(this).addClass('submenu');
//     } else if($(this).hasClass('submenu')) {
//         $(this).removeClass('submenu');
//         $(this).next('ul').slideUp(350);
//     }
// });
