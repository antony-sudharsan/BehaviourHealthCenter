
export { default as IMG01} from '../../../../assets/images/doctor-thumb-02.jpg';
