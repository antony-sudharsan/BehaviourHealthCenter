export { default as IMG01} from '../../../assets/images/patient1.jpg';
export { default as IMG02} from '../../../assets/images/doctor-thumb-02.jpg';
