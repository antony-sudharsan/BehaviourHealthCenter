export { default as IMG01} from '../../../assets/images/video-call.jpg';
export { default as IMG02} from '../../../assets/images/doctor-thumb-02.jpg';
