
export { default as Icon01} from '../../../assets/images/icon-01.png';
export { default as Icon02} from '../../../assets/images/icon-02.png';
export { default as Icon03} from '../../../assets/images/icon-03.png';

export { default as IMG04} from '../../../assets/images/patient3.jpg';
export { default as IMG05} from '../../../assets/images/patient4.jpg';
export { default as IMG06} from '../../../assets/images/patient5.jpg';
export { default as IMG01} from '../../../assets/images/patient6.jpg';
export { default as IMG02} from '../../../assets/images/patient7.jpg';
export { default as IMG03} from '../../../assets/images/patient8.jpg';

