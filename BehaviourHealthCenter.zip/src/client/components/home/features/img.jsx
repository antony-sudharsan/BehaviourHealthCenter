export { default as IMG} from '../../../assets/images/feature.png';
export { default as IMG01} from '../../../assets/images/feature-01.jpg';
export { default as IMG02} from '../../../assets/images/feature-02.jpg';
export { default as IMG03} from '../../../assets/images/feature-03.jpg';
export { default as IMG04} from '../../../assets/images/feature-04.jpg';
export { default as IMG05} from '../../../assets/images/feature-05.jpg';
export { default as IMG06} from '../../../assets/images/feature-06.jpg';



