export { default as IMG01} from '../../../assets/images/blog-01.jpg';
export { default as IMG02} from '../../../assets/images/blog-02.jpg';
export { default as IMG03} from '../../../assets/images/blog-03.jpg';
export { default as IMG04} from '../../../assets/images/blog-04.jpg';
export { default as IMG_th01} from '../../../assets/images/doctors/doctor-thumb-01.jpg';
export { default as IMG_th02} from '../../../assets/images/doctors/doctor-thumb-02.jpg';
export { default as IMG_th03} from '../../../assets/images/doctors/doctor-thumb-03.jpg';
export { default as IMG_th04} from '../../../assets/images/doctors/doctor-thumb-04.jpg';

