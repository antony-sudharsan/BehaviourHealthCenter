export { default as IMG01} from '../../../assets/images/specialities-01.png';
export { default as IMG02} from '../../../assets/images/specialities-02.png';
export { default as IMG03} from '../../../assets/images/specialities-03.png';
export { default as IMG04} from '../../../assets/images/specialities-04.png';
export { default as IMG05} from '../../../assets/images/specialities-05.png';

