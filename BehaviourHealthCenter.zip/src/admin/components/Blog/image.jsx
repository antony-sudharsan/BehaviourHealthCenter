export { default as IMG01} from '../../assets/images/blog/blog-01.jpg';
export { default as IMG02} from '../../assets/images/blog/blog-02.jpg';
export { default as IMG03} from '../../assets/images/blog/blog-03.jpg';
export { default as IMG04} from '../../assets/images/blog/blog-04.jpg';
export { default as IMG05} from '../../assets/images/blog/blog-05.jpg';
export { default as IMG06} from '../../assets/images/blog/blog-06.jpg';
export { default as IMG07} from '../../assets/images/blog/blog-07.jpg';
export { default as IMG08} from '../../assets/images/blog/blog-08.jpg';
export { default as IMG09} from '../../assets/images/blog/blog-09.jpg';
export { default as IMG10} from '../../assets/images/blog/blog-10.jpg';

export { default as DoctorThumb01} from '../../assets/images/doctors/doctor-thumb-01.jpg';
export { default as DoctorThumb02} from '../../assets/images/doctors/doctor-thumb-02.jpg';
export { default as DoctorThumb03} from '../../assets/images/doctors/doctor-thumb-03.jpg';
export { default as DoctorThumb04} from '../../assets/images/doctors/doctor-thumb-04.jpg';
export { default as DoctorThumb05} from '../../assets/images/doctors/doctor-thumb-05.jpg';
export { default as DoctorThumb06} from '../../assets/images/doctors/doctor-thumb-06.jpg';
export { default as DoctorThumb07} from '../../assets/images/doctors/doctor-thumb-07.jpg';
export { default as DoctorThumb08} from '../../assets/images/doctors/doctor-thumb-08.jpg';
export { default as DoctorThumb09} from '../../assets/images/doctors/doctor-thumb-09.jpg';
export { default as DoctorThumb10} from '../../assets/images/doctors/doctor-thumb-10.jpg';

export { default as patient3} from '../../assets/images/patient3.jpg';
export { default as patient4} from '../../assets/images/patient4.jpg';
export { default as patient5} from '../../assets/images/patient5.jpg';
export { default as patient6} from '../../assets/images/patient6.jpg';
export { default as patient7} from '../../assets/images/patient7.jpg';
export { default as Avatar17} from '../../assets/images/avatar-17.jpg';