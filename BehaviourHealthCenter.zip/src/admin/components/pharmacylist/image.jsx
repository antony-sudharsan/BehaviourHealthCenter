export { default as IMG01} from '../../assets/images/features/feature-01.jpg';
export { default as IMG02} from '../../assets/images/features/feature-02.jpg';