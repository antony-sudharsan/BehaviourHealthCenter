import React, {Component} from 'react';
import SidebarNav from '../../sidebar';

class FormInput extends Component{

    render(){
        return(
			<>
			<SidebarNav />
            
           </>
        );
    }
}
export default FormInput;