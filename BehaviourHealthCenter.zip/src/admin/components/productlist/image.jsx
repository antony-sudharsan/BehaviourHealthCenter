export { default as IMG01} from '../../assets/images/product/product.jpg';
