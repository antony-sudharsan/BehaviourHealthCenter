export { default as Productss} from '../../assets/images/product/product.jpg';
export { default as Product1} from '../../assets/images/product/product1.jpg';
export { default as Product2} from '../../assets/images/product/product2.jpg';
export { default as Product10} from '../../assets/images/product/product10.jpg';
export { default as Product11} from '../../assets/images/product/product11.jpg';
export { default as Product12} from '../../assets/images/product/product12.jpg';
export { default as Product13} from '../../assets/images/product/product13.jpg';
export { default as Product14} from '../../assets/images/product/product14.jpg';
